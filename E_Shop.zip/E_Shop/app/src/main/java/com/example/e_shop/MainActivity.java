package com.example.e_shop;

enum MainActivity {
}
